﻿using DAL.Entities;

namespace DAL.Interfaces
{
    public interface IAnswerRepository : IRepository<Answer>
    {
    }
}
