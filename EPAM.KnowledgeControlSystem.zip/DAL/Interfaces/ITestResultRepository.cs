﻿using DAL.Entities;

namespace DAL.Interfaces
{
    public interface ITestResultRepository : IRepository<TestResult>
    {
    }
}
