﻿namespace WebUI.ViewModels
{
    public class ProfileViewModel
    {
        public UserViewModel User { get; set; }
        public PageInfoViewModel PageInfo { get; set; }
    }
}