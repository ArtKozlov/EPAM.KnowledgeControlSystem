﻿namespace BLL.Interfaces
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
